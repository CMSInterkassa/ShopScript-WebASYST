<?php
return array(
    'name'        => 'Интеркасса',
    'description' => 'Платежная система «<a href="http://www.new.interkassa.com">Интеркасса</a>»',
    'icon'        => 'img/interkassa16.png',
    'logo'        => 'img/interkassa.png',
    'vendor'      => 'webasyst',
    'version'     => '1.0.1',
    'locale'      => array('ru_RU',),
    'type'        => waPayment::TYPE_ONLINE,
);
